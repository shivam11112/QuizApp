package com.example.android.quizapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatRadioButton;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Find the ids of Radio Groups
        final RadioGroup r1 = (RadioGroup) findViewById(R.id.r1);
        final RadioGroup r2 = (RadioGroup) findViewById(R.id.r2);
        final RadioGroup r3 = (RadioGroup) findViewById(R.id.r3);
        final RadioGroup r4 = (RadioGroup) findViewById(R.id.r4);
        final RadioGroup r5 = (RadioGroup) findViewById(R.id.r5);
        final RadioGroup r6 = (RadioGroup) findViewById(R.id.r6);
        final RadioGroup r7 = (RadioGroup) findViewById(R.id.r7);
        final RadioGroup r8 = (RadioGroup) findViewById(R.id.r8);
        final RadioGroup r9 = (RadioGroup) findViewById(R.id.r9);
        final RadioGroup r10 = (RadioGroup) findViewById(R.id.r10);
        //find the ids of buttons
        Button reset = (Button) findViewById(R.id.reset);
        Button submit = (Button) findViewById(R.id.submit);

// Set a click listener on that reset Button
        reset.setOnClickListener(new View.OnClickListener()

        {
            // The code in this method will be executed when the numbers View is clicked on.
            @Override
            public void onClick(View view) {
                r1.clearCheck();
                r2.clearCheck();
                r3.clearCheck();
                r4.clearCheck();
                r5.clearCheck();
                r6.clearCheck();
                r7.clearCheck();
                r8.clearCheck();
                r9.clearCheck();
                r10.clearCheck();
                score = 0;
            }
        });
        submit.setOnClickListener(new View.OnClickListener()

        {
            // The code in this method will be executed when the numbers View is clicked on.
            @Override
            public void onClick(View view) {
                Context context = getApplicationContext();
                CharSequence text = "you have got " + score + "/10";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        });

    }

    public void onRadioButtonClicked(View view) {

        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch (view.getId()) {

            case R.id.qn4_radio_button:
                if (checked) {
                    score += 1;
                    break;
                }
            case R.id.qn22_radio_button:
                if (checked) {
                    score += 1;
                    break;
                }
            case R.id.qn32_radio_button:
                if (checked) {
                    score += 1;
                    break;
                }

            case R.id.qn42_radio_button:
                if (checked) {
                    score += 1;
                    break;
                }


            case R.id.qn51_radio_button:
                if (checked) {
                    score += 1;
                    break;
                }


            case R.id.qn64_radio_button:
                if (checked) {
                    score += 1;
                    break;
                }


            case R.id.qn72_radio_button:
                if (checked) {
                    score += 1;
                    break;
                }

            case R.id.qn81_radio_button:
                if (checked) {
                    score += 1;
                    break;
                }
            case R.id.qn94_radio_button:
                if (checked) {
                    score += 1;
                    break;
                }
            case R.id.qn102_radio_button:
                if (checked) {
                    score += 1;
                    break;
                }


        }

    }
}
